 #!/usr/bin/python
# -*- coding: utf-8 -*-

"""
=========================================================
K-means Clustering
=========================================================


"""
print(__doc__)


# Code source: Gaël Varoquaux
# Modified for documentation by Jaques Grobler
# License: BSD 3 clause

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


from sklearn.cluster import KMeans
from sklearn import datasets

# Read the excel sheet to pandas dataframe
df = pd.read_excel("data.xlsx", sheetname=0)
df2 = pd.read_excel("data.xlsx", sheetname=2)

np.random.seed(200)

k = 3
# centroids[i] = [x, y]
centroids = {
    i + 1: [np.random.randint(0, 80), np.random.randint(0, 80)]
    for i in range(k)
    }

X = df #iris.data
y2 = df2 #iris.target
#y = y2.flatten()


est = KMeans(n_clusters=3)
est.fit(X)
labels = est.labels_
centroids = est.cluster_centers_

fig = plt.figure("Before Classification", figsize=(5, 5))
plt.clf()
plt.cla()
labels = est.labels_
#plt.scatter(X.iloc[:,1], X.iloc[:,3], color='b', alpha=1, edgecolor='k', )
plt.scatter(X.iloc[:,1], X.iloc[:,3], alpha=1, edgecolor='k', )
# plt.xlabel('Sex')
# plt.ylabel('ROUTE OF DRUG ADMINSTRATION')
fig = plt.figure("K Means Clusters 3", figsize=(4, 5))
plt.clf()
plt.cla()
colormap = np.array(['r', 'g', 'b'])
plt.scatter(X.iloc[:,1], X.iloc[:,3], c=colormap[labels], alpha=1, edgecolor='k')
#plt.scatter(X.iloc[:,1], X.iloc[:,3], color=colormap[labels], alpha=0.5,)
# plt.xlabel('Sex')
# plt.ylabel('ROUTE OF DRUG ADMINSTRATION')
colmap = {1: 'r', 2: 'g', 3: 'b'}
for idx, centroid in enumerate(centroids):
    print(centroid[1], centroid[3])
    plt.scatter(centroid[1], centroid[3], color=colmap[idx+1], marker='x', s=500)
plt.xlim(0, 15)
plt.ylim(0, 150)
plt.show()
